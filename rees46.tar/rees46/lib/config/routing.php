<?php

return array(
    'rees46/' => 'frontend/rees46'    
);