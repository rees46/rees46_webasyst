<?php
return array(
    'r46getitems/' => 'frontend/r46getitems'
);

