<?php
return array(
    'php.curl' => array(
        'name' => 'cURL',
        'description' => 'Обмен данными с серверами REES46',
        'strict' => true
   ),
    'php' => array(
        'version' => '>=5.3',
        'strict' => true
    )
);